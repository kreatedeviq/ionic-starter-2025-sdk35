import { Injectable, Inject } from '@angular/core';
import { DOCUMENT } from '@angular/common';
import { Storage } from '@ionic/storage-angular';
import { Platform } from '@ionic/angular';
import { BehaviorSubject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class ThemeService {
  private darkMode = new BehaviorSubject<boolean>(false);
  public darkMode$ = this.darkMode.asObservable();
  private themeKey = 'selected_theme';

  constructor(
    @Inject(DOCUMENT) private document: Document,
    private storage: Storage,
    private platform: Platform
  ) {
    this.initialize();
  }

  async initialize(): Promise<void> {
    // Wait for storage to be ready
    await this.storage.create();
    
    // Get the user's preference from storage if available
    const savedTheme = await this.storage.get(this.themeKey);
    
    if (savedTheme !== null) {
      // Use the saved preference
      this.setTheme(savedTheme === 'dark');
    } else {
      // Use the system preference if no saved preference
      const prefersDark = window.matchMedia('(prefers-color-scheme: dark)');
      this.setTheme(prefersDark.matches);
      
      // Listen for changes to the prefers-color-scheme media query
      prefersDark.addEventListener('change', (mediaQuery) => {
        this.setTheme(mediaQuery.matches);
      });
    }
  }

  /**
   * Toggle between light and dark themes
   */
  toggleTheme(): void {
    this.setTheme(!this.darkMode.value);
  }

  /**
   * Set the theme to dark or light
   * @param dark Whether to enable dark mode
   */
  async setTheme(dark: boolean): Promise<void> {
    this.darkMode.next(dark);
    
    if (dark) {
      this.document.body.classList.add('dark-theme');
    } else {
      this.document.body.classList.remove('dark-theme');
    }
    
    // Save the user's preference to storage
    await this.storage.set(this.themeKey, dark ? 'dark' : 'light');
  }
}